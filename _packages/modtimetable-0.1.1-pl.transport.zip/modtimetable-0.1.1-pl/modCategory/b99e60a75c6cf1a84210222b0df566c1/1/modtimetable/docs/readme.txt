---------------------------------------
modTimetable
---------------------------------------
Version: 0.0.1
Author: Murray Wood <murray@digitalpenguin.hk>
---------------------------------------