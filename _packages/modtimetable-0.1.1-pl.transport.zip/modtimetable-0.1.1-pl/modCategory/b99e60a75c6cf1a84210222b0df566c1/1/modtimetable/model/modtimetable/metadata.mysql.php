<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'modTimetableObject',
    1 => 'modTimetableExtraFieldClosure',
    2 => 'modTimetableExtraField',
  ),
  'modTimetableObject' => 
  array (
    0 => 'modTimetableTimetable',
    1 => 'modTimetableDay',
    2 => 'modTimetableSession',
  ),
);