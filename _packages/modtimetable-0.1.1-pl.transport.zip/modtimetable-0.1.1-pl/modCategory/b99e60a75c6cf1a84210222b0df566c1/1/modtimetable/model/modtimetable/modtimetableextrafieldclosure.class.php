<?php
/**
 * @package modtimetable
 */
class modTimetableExtraFieldClosure extends xPDOSimpleObject {}
?>