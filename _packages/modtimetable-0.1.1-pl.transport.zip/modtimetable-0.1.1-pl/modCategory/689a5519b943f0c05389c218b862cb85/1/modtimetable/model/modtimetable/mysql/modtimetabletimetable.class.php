<?php
/**
 * @package modtimetable
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/modtimetabletimetable.class.php');
class modTimetableTimetable_mysql extends modTimetableTimetable {}
?>