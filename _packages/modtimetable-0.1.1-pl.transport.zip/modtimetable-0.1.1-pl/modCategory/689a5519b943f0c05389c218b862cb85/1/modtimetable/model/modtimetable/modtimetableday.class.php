<?php
/**
 * @package modtimetable
 */
class modTimetableDay extends modTimetableObject {}
?>