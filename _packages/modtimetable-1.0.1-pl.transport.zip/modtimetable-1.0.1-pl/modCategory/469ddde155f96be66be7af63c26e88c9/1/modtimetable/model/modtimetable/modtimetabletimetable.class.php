<?php
/**
 * @package modtimetable
 */
class modTimetableTimetable extends modTimetableObject {}
?>