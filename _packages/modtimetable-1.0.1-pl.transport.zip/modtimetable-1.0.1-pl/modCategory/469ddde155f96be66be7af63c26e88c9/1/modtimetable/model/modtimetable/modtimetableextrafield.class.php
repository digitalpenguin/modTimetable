<?php
/**
 * @package modtimetable
 */
class modTimetableExtraField extends xPDOSimpleObject {}
?>