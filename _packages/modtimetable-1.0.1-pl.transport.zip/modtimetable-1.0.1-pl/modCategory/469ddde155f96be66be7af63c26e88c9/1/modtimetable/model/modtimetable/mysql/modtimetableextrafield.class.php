<?php
/**
 * @package modtimetable
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/modtimetableextrafield.class.php');
class modTimetableExtraField_mysql extends modTimetableExtraField {}
?>