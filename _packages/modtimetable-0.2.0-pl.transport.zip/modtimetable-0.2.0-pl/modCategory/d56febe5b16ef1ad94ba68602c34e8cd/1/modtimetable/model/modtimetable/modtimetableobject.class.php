<?php
/**
 * @package modtimetable
 */
class modTimetableObject extends xPDOSimpleObject {}
?>