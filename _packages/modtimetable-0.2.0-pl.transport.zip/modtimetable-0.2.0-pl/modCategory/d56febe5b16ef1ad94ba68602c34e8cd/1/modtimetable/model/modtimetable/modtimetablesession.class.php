<?php
/**
 * @package modtimetable
 */
class modTimetableSession extends modTimetableObject {}
?>